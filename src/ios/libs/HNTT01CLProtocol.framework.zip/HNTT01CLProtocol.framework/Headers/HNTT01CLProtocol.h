//
//  HNTT01CLProtocol.h
//  HNTT01CLProtocol
//
//  Created by 陈志勇 on 2017/9/15.
//  Copyright © 2017年 陈志勇. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HNTT01BleLock.h"

//! Project version number for HNTT01CLProtocol.
FOUNDATION_EXPORT double HNTT01CLProtocolVersionNumber;

//! Project version string for HNTT01CLProtocol.
FOUNDATION_EXPORT const unsigned char HNTT01CLProtocolVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HNTT01CLProtocol/PublicHeader.h>


